import React from 'react'

import { Helmet } from 'react-helmet'

import AddEditTasks from '../components/add-edit-tasks'
import ListsTasks from '../components/lists-tasks'
import SignInUp from '../components/sign-in-up'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>User tasks</title>
        <meta property="og:title" content="User tasks" />
      </Helmet>
      <h1 className="home-text">User tasks</h1>
      <div className="home-task-container">
        <AddEditTasks rootClassName="add-edit-tasks-root-class-name"></AddEditTasks>
        <ListsTasks rootClassName="lists-tasks-root-class-name"></ListsTasks>
      </div>
      <SignInUp rootClassName="sign-in-up-root-class-name"></SignInUp>
      <span className="home-footer">pablo_spector@hotmail.com</span>
    </div>
  )
}

export default Home
