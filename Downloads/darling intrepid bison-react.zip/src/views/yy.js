import React from 'react'

import { Helmet } from 'react-helmet'

import './yy.css'

const Yy = (props) => {
  return (
    <div className="yy-container">
      <Helmet>
        <title>yy - Darling Intrepid Bison</title>
        <meta property="og:title" content="yy - Darling Intrepid Bison" />
      </Helmet>
      <select>
        <option value="Option 1">Option 1</option>
        <option value="Option 2">Option 2</option>
        <option value="Option 3">Option 3</option>
      </select>
      <label>Label</label>
      <svg viewBox="0 0 1024 1024" className="yy-icon">
        <path d="M554 598v-172h-84v172h84zM554 768v-86h-84v86h84zM42 896l470-810 470 810h-940z"></path>
      </svg>
      <textarea placeholder="placeholder" className="textarea"></textarea>
      <img
        alt="image"
        src="https://play.teleporthq.io/static/svg/default-img.svg"
        className="yy-image"
      />
      <ul className="list">
        <li className="list-item">
          <span>Text</span>
        </li>
        <li className="list-item">
          <span>Text</span>
        </li>
        <li className="list-item">
          <span>Text</span>
        </li>
      </ul>
      <button className="yy-button button">Button</button>
      <iframe
        src="https://www.youtube.com/embed/DeQkMK5LME4"
        className="yy-iframe"
      ></iframe>
    </div>
  )
}

export default Yy
