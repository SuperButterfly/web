import React from 'react'

import PropTypes from 'prop-types'

import './lists-tasks.css'

const ListsTasks = (props) => {
  return (
    <div className={`lists-tasks-lists-tasks ${props.rootClassName} `}>
      <h3 className="">{props.heading1}</h3>
      <div className="lists-tasks-container">
        <ul className="lists-tasks-ul">
          <li className="lists-tasks-li">
            <div className="lists-tasks-container1">
              <span className="">{props.text6}</span>
              <button className="lists-tasks-button">
                <span className="">
                  <span className="">view</span>
                  <br className=""></br>
                </span>
              </button>
            </div>
          </li>
        </ul>
      </div>
    </div>
  )
}

ListsTasks.defaultProps = {
  rootClassName: '',
  text6: 'title',
  heading1: 'List tasks',
}

ListsTasks.propTypes = {
  rootClassName: PropTypes.string,
  text6: PropTypes.string,
  heading1: PropTypes.string,
}

export default ListsTasks
