import React from 'react'

import './hero5.css'

const Hero5 = (props) => {
  return (
    <div className="hero5-hero5">
      <div className="hero5-container">
        <h1 className="hero5-text">Let&apos;s keep things organised</h1>
        <span className="hero5-text1">
          <span>
            <span>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non
              volutpat turpis.
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span>
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </span>
          <span>
            <span>
              Mauris luctus rutrum mi ut rhoncus. Integer in dignissim tortor.
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span>
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </span>
        </span>
        <button className="hero5-button">Get Started</button>
      </div>
    </div>
  )
}

export default Hero5
