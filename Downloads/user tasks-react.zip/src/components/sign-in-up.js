import React from 'react'

import PropTypes from 'prop-types'

import './sign-in-up.css'

const SignInUp = (props) => {
  return (
    <div className={`sign-in-up-sign-in-up ${props.rootClassName} `}>
      <div className="sign-in-up-container">
        <label className="">{props.text}</label>
        <input
          type="text"
          placeholder={props.textinput_placeholder}
          className="sign-in-up-textinput"
        />
      </div>
      <div className="sign-in-up-container1">
        <label className="">{props.text1}</label>
        <input
          type="text"
          placeholder={props.textinput_placeholder1}
          className="sign-in-up-textinput1"
        />
      </div>
      <div className="sign-in-up-container2">
        <button className="sign-in-up-button">{props.button}</button>
        <p className="sign-in-up-text2">{props.text2}</p>
      </div>
    </div>
  )
}

SignInUp.defaultProps = {
  text1: 'Password',
  text2: 'already have a count?',
  rootClassName: '',
  textinput_placeholder1: 'secret',
  text: 'Name\n',
  button: 'register login\n',
  textinput_placeholder: 'user',
}

SignInUp.propTypes = {
  text1: PropTypes.string,
  text2: PropTypes.string,
  rootClassName: PropTypes.string,
  textinput_placeholder1: PropTypes.string,
  text: PropTypes.string,
  button: PropTypes.string,
  textinput_placeholder: PropTypes.string,
}

export default SignInUp
