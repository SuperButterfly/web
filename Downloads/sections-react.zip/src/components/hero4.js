import React from 'react'

import './hero4.css'

const Hero4 = (props) => {
  return (
    <div className="hero4-hero4">
      <h1 className="hero4-text">Let&apos;s keep things organized</h1>
      <span className="hero4-text1">
        <span>
          <span>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non
            volutpat turpis.
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
          <span>
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
        </span>
        <br></br>
        <span>
          <span>
            Mauris luctus rutrum mi ut rhoncus. Integer in dignissim tortor.
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
          <span>
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
        </span>
      </span>
      <div className="hero4-btn-group">
        <button className="hero4-button">Get Started</button>
        <button className="hero4-button1">Learn More</button>
      </div>
    </div>
  )
}

export default Hero4
