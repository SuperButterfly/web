import React from 'react'

import { Helmet } from 'react-helmet'

import './yy.css'

const Yy = (props) => {
  return (
    <div className="yy-container">
      <Helmet>
        <title>yy - Darling Intrepid Bison</title>
        <meta property="og:title" content="yy - Darling Intrepid Bison" />
      </Helmet>
      <ul className="yy-list button">
        <li className="list-item">
          <span>Text</span>
        </li>
        <li className="list-item">
          <span>Text</span>
        </li>
        <li className="list-item">
          <span>Text</span>
        </li>
      </ul>
      <button className="yy-button button">Button</button>
      <iframe
        src="https://www.youtube.com/embed/DeQkMK5LME4"
        className="yy-iframe"
      ></iframe>
    </div>
  )
}

export default Yy
