import React from 'react'

import PropTypes from 'prop-types'

import './add-edit-tasks.css'

const AddEditTasks = (props) => {
  return (
    <div className={`add-edit-tasks-add-edit-tasks ${props.rootClassName} `}>
      <h3 className="">
        <span className="">Add tasks</span>
        <br className=""></br>
      </h3>
      <div className="add-edit-tasks-container">
        <div className="add-edit-tasks-container1">
          <label className="">{props.text3}</label>
          <input
            type="text"
            placeholder={props.textinput_placeholder2}
            className="add-edit-tasks-textinput"
          />
        </div>
        <div className="add-edit-tasks-container2">
          <label className="">{props.text4}</label>
          <textarea
            rows="3"
            placeholder={props.textarea_placeholder}
            className="add-edit-tasks-textarea"
          ></textarea>
        </div>
        <div className="add-edit-tasks-container3">
          <div className="add-edit-tasks-container4">
            <svg viewBox="0 0 1024 1024" className="add-edit-tasks-icon">
              <path
                d="M864 128l-480 480-224-224-160 160 384 384 640-640z"
                className=""
              ></path>
            </svg>
          </div>
          <span className="">{props.text5}</span>
        </div>
        <div className="add-edit-tasks-container5">
          <button className="add-edit-tasks-button">{props.button1}</button>
          <button className="add-edit-tasks-button1">{props.button2}</button>
        </div>
      </div>
    </div>
  )
}

AddEditTasks.defaultProps = {
  rootClassName: '',
  textinput_placeholder2: 'what to do',
  button1: 'add update',
  button2: 'delete',
  text4: 'Description',
  text3: 'Title',
  text5: 'Status',
  textarea_placeholder: 'exactly what',
}

AddEditTasks.propTypes = {
  rootClassName: PropTypes.string,
  textinput_placeholder2: PropTypes.string,
  button1: PropTypes.string,
  button2: PropTypes.string,
  text4: PropTypes.string,
  text3: PropTypes.string,
  text5: PropTypes.string,
  textarea_placeholder: PropTypes.string,
}

export default AddEditTasks
