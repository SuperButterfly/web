import React from 'react'

import './hero6.css'

const Hero6 = (props) => {
  return (
    <div className="hero6-hero6">
      <span className="hero6-text">
        <span className="hero6-text1">Lorem ipsum dolor sit amet</span>
      </span>
      <h1 className="hero6-text2">Magnificent things are very simple</h1>
      <button className="hero6-button">Get Started</button>
    </div>
  )
}

export default Hero6
